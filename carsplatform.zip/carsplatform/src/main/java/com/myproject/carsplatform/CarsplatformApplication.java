package com.myproject.carsplatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarsplatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarsplatformApplication.class, args);
	}

}
